-- MySQL dump 10.13  Distrib 9.2.0, for Win64 (x86_64)
--
-- Host: mysql-2fc56c0d-nextstepdb.h.aivencloud.com    Database: NextStep-DB
-- ------------------------------------------------------
-- Server version	8.4.8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '953f0bd3-787a-11f1-8ad7-62520a8a2704:1-392,
efaa9187-706a-11f1-9685-be89a004a75d:1-51';

--
-- Table structure for table `AcademicUnits`
--

DROP TABLE IF EXISTS `AcademicUnits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AcademicUnits` (
  `academicUnitId` int NOT NULL AUTO_INCREMENT,
  `universityId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` enum('Faculty','Institute','Department','College','School') NOT NULL,
  `description` text,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`academicUnitId`),
  KEY `universityId` (`universityId`),
  CONSTRAINT `AcademicUnits_ibfk_1` FOREIGN KEY (`universityId`) REFERENCES `Universities` (`universityId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AcademicUnits`
--

LOCK TABLES `AcademicUnits` WRITE;
/*!40000 ALTER TABLE `AcademicUnits` DISABLE KEYS */;
INSERT INTO `AcademicUnits` VALUES (1,2,'Institute of Foreign Languages','Institute','The Institute of Foreign Languages IFL is a prominent educational institution under the Royal University of Phnom Penh (RUPP), dedicated to providing comprehensive language education. Established as part of RUPP, IFL plays a crucial role in enhancing language skills among students in Cambodia.','2026-07-05 14:28:54','2026-07-05 14:28:54'),(2,2,'Faculty of Science','Faculty','The Faculty of Science is dedicated to high-quality teaching, pioneering research, and community service. Its primary goal is to produce graduates with the theoretical knowledge and practical technical skills necessary to support Cambodia’s goal of becoming an upper-middle-income country by 2030.','2026-07-05 14:29:06','2026-07-05 14:29:06'),(3,2,'Faculty of Engineering','Faculty','The Faculty of Engineering is dedicated to pursuing excellence in teaching, research, and community engagement in Engineering Education to address the challenges of ever-changing society and globalization.','2026-07-05 14:29:14','2026-07-05 14:29:14'),(4,2,'Institute For International Studies and Public Policy','Institute','The central goal of IISPP is to produce well-rounded and skillful graduates who possess the in-depth knowledge and critical analytical, research, and transferable skills necessary to successfully contribute to careers in international affairs, economics, and public policy, thus supporting the country\'s strong, robust system and socio-economic development.','2026-07-05 14:29:23','2026-07-05 14:29:23'),(5,2,'Faculty of Development Studies','Faculty','The Faculty of Development Studies is dedicated to providing high-quality education and research in the field of development studies, preparing students to address the complex challenges of sustainable development in Cambodia and beyond.','2026-07-05 14:29:30','2026-07-05 14:29:30'),(6,2,'Faculty of Education','Faculty','The Faculty of Education is committed to training future educators and researchers, equipping them with the knowledge, skills, and ethical foundations necessary to contribute effectively to the educational development of Cambodia.','2026-07-05 14:29:38','2026-07-05 14:29:38'),(7,2,'Faculty of Social Sciences and Humanities','Faculty','The Faculty of Social Sciences and Humanities is dedicated to providing high-quality education and research in the fields of social sciences and humanities, preparing students to address the complex challenges of modern society.','2026-07-05 14:29:45','2026-07-05 14:29:45'),(8,3,'Faculty of Electrical Engineering','Faculty','The Faculty of Electrical Engineering prepares students to design, develop, and maintain modern electrical and electronic systems. It offers programs in electrical and energy engineering, industrial and mechanical engineering, information and communication engineering, and telecommunications, combining theoretical knowledge with practical laboratory experience.','2026-07-06 06:38:17','2026-07-06 06:38:17'),(9,3,'Faculty of Civil Engineering','Faculty','The Faculty of Civil Engineering focuses on designing and constructing sustainable infrastructure. Students gain expertise in structural engineering, transportation systems, and architectural engineering through project-based learning and practical engineering applications.','2026-07-06 06:38:31','2026-07-06 06:38:31'),(10,3,'Faculty of Chemical and Food Engineering','Faculty','The Faculty of Chemical and Food Engineering equips students with expertise in chemical processes, food production, quality assurance, and industrial manufacturing. The curriculum emphasizes sustainability, innovation, and industry-oriented research.','2026-07-06 06:38:45','2026-07-06 06:38:45'),(11,3,'Faculty of Hydrology and Water Resources Engineering','Faculty','The Faculty of Hydrology and Water Resources Engineering prepares students to manage water resources, environmental systems, irrigation, flood control, and sustainable infrastructure through engineering principles and applied research.','2026-07-06 06:38:57','2026-07-06 06:38:57'),(12,3,'Faculty of Geo-resources and Geotechnical Engineering','Faculty','The Faculty of Geo-resources and Geotechnical Engineering focuses on geology, geotechnical engineering, soil mechanics, foundation engineering, and the sustainable development of natural resources for modern infrastructure.','2026-07-06 06:39:08','2026-07-06 06:39:08'),(13,1,'Faculty of Computer Science','Faculty','The Faculty of Computer Science emphasizes practical skills built on theoretical foundations. Every course is designed to give students hands-on practices with up-to-date tools and frameworks','2026-07-06 06:39:22','2026-07-06 06:39:22'),(14,1,'Faculty of Telecommunication and Network Engineering','Faculty','The Faculty of Telecommunication and Network Engineering is designed to provide students with a firmly-grounded, practical, and multidisciplinary training with effective learning resources.','2026-07-06 06:39:33','2026-07-06 06:39:33'),(15,1,'Faculty of Digital Business','Faculty','The Faculty of Digital Business is designed to prepare students for the contemporary workforce and a global career especially for the emerging market.','2026-07-06 06:39:45','2026-07-06 06:39:45'),(16,4,'Faculty of Management','Faculty','The Faculty of Management is dedicated to cultivating skilled professionals in management, marketing, and entrepreneurship. It aims to equip students with the knowledge and practical skills necessary to excel in the dynamic industry environment of Cambodia and beyond.','2026-07-06 06:41:07','2026-07-06 06:41:07'),(17,4,'Faculty of Finance and Accounting','Faculty','The Faculty of Finance and Accounting is designed to equip students with strong theoretical knowledge and practical skills in financial reporting, auditing, taxation, and management accounting.','2026-07-06 06:41:22','2026-07-06 06:41:22'),(18,4,'Faculty of Information Technology','Faculty','The Faculty of Information Technology prepares students to become innovative problem-solvers and technology leaders in the digital era.','2026-07-06 06:41:32','2026-07-06 06:41:32'),(19,4,'Faculty of Economics','Faculty','The Faculty of Economics aims to produce graduates that are equipped with sound knowledge and understanding of broad social, political, business and economic phenomena, with the analytical tools to perform work and apply with business efficiently and effectively.','2026-07-06 06:41:51','2026-07-06 06:41:51'),(20,4,'Faculty of Foreign Languages','Faculty','The Faculty of Foreign Languages is designed to equip students with English proficiency for professional communication and English teaching skills.','2026-07-06 06:42:04','2026-07-06 06:42:04'),(21,4,'Faculty of Tourism and Hospitality','Faculty','The Faculty of Tourism and Hospitality Management is focused on tourism management, hospitality services, and customer experience to prepare professionals for the growing tourism industry.','2026-07-06 06:42:13','2026-07-06 06:42:13'),(22,4,'Faculty of Law','Faculty','The Faculty of Law is dedicated to excellence in legal education, research and innovation- cultivating the next generation of leaders in law and justice with a profound understanding of Cambodian and international law.','2026-07-06 06:42:24','2026-07-06 06:42:24'),(23,5,'Faculty of Engineering','Faculty','The Faculty of Engineering strives to prepare its students with the highest quality education and research who will endure the challenges of the industry and the society competently.','2026-07-06 06:42:35','2026-07-06 06:42:35'),(24,5,'Faculty of Information and Computer Technologyies','Faculty','The Faculty of Information and Computer Technology is committed to providing students with a comprehensive understanding of computer science, information systems, and emerging technologies, preparing them for successful careers in the digital age.','2026-07-06 06:42:46','2026-07-06 06:42:46'),(25,5,'Faculty of Economics and Administrative Sciences','Faculty','The Faculty is dedicated to offering students with majors tailored to modern corporate and diplomatic needs, including Banking and Finance, Business Administration, International Trade and Logistics, Economics, and International Relations.','2026-07-06 06:43:00','2026-07-06 06:43:00'),(26,6,'Faculty of Business and Management','Faculty','This faculty is designed for students aiming to enter the global corporate world, start their own ventures, or enter marketing. It focuses heavily on hands-on experiences and modern market trends.','2026-07-06 06:43:14','2026-07-06 06:43:14'),(27,6,'Faculty of Digital Technologies','Faculty','The Faculty is dedicated to Digital Infrastructure, Software Development, Cybersecurity, Data Science, and AI. Our specialized programs equip students with practical expertise and in-depth knowledge in these critical tech domains.','2026-07-06 06:43:23','2026-07-06 06:43:23'),(28,6,'Faculty of Law','Faculty','The Faculty of Law designed to help students develop legal analysis, critical thinking, and problem-solving skills that will equip them for careers not only in the legal profession, but also in business, government, and other professions.','2026-07-06 06:43:31','2026-07-06 06:43:31'),(29,6,'Faculty of Social Sciences','Faculty','The Faulty houses the GE program enables students in all majors to experience interdisciplinary American style education by exposing them to a variety of subjects, and enabling them in their first years of study to acquire the necessary academic skills to succeed in their respective programs.','2026-07-06 06:43:37','2026-07-06 06:43:37');
/*!40000 ALTER TABLE `AcademicUnits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Admissions`
--

DROP TABLE IF EXISTS `Admissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Admissions` (
  `admissionId` int NOT NULL AUTO_INCREMENT,
  `universityId` int NOT NULL,
  `title` text NOT NULL,
  `requirements` json DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `description` text,
  `contact` json NOT NULL,
  PRIMARY KEY (`admissionId`),
  KEY `universityId` (`universityId`),
  CONSTRAINT `Admissions_ibfk_1` FOREIGN KEY (`universityId`) REFERENCES `Universities` (`universityId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Admissions`
--

LOCK TABLES `Admissions` WRITE;
/*!40000 ALTER TABLE `Admissions` DISABLE KEYS */;
INSERT INTO `Admissions` VALUES (1,6,'Bachelor\'s Degree Admission Requirements','{\"proof_of_identity\": {\"options\": [\"Cambodia National Identity Card\", \"Passport\", \"Birth Certificate\"], \"description\": \"You must submit one of your official identification documents for verification:\"}, \"proof_of_english_proficiency\": {\"options\": [\"IELTS overall score of a 6.0\", \"TOEFL iBT score of at least 79\", \"Duolingo score of 110 or higher\", \"Cambridge English (B2 First/C1 Advanced) score of 169 or higher\", \"AUPP English Placement Test (EPT): If you do not have an official IELTS/TOEFL score, you can pay a $15 fee to take AUPP’s internal exam\"], \"description\": \"Since all classes are taught in English, you must meet one of the following conditions to enter straight into a Bachelor\'s degree program:\"}, \"proof_of_high_school_graduation\": {\"options\": [\"A High School National Diploma (Grade 12 certificate)\", \"An official High School Transcript / Grade Report\"], \"description\": \"You must provide official proof that you have successfully completed high school:\"}}','2026-07-10 18:19:40','2026-07-10 18:19:40','Comprehensive admission criteria for entering undergraduate programs at the American University of Phnom Penh (AUPP).','{\"tel\": \"012 266 631\", \"email\": \"admissions@aupp.edu.kh\", \"office_location\": \"AUPP Campus: Room A8 (Reception Area)\"}'),(2,1,'Bachelor\'s Degree Admission Requirements','{\"proof_of_identity\": {\"options\": [\"Cambodia National Identity Card\", \"Passport\", \"Birth Certificate\"], \"description\": \"You must submit one of your official identification documents for verification:\"}, \"entrance_examination\": {\"options\": [\"Mathematics foundational knowledge test\", \"Logic and reasoning evaluation paper\", \"English language proficiency test section\"], \"description\": \"All candidates must pass the official computer-based capacity assessment test organized by the Institute of Digital Technology:\"}, \"proof_of_high_school_graduation\": {\"options\": [\"A High School National Diploma (Grade 12 certificate from graduation years 2021 to 2026)\", \"Open to all passing marks/grades (A to E) from both the Science and Social Science tracks\", \"An official High School Transcript / Grade Report\"], \"description\": \"You must provide official proof that you have successfully completed high school:\"}}','2026-07-14 07:51:44','2026-07-14 07:51:44','Comprehensive admission criteria for entering undergraduate programs at the Cambodia Academy of Digital Technology (CADT).','{\"tel\": \"015 335 877 / 077 335 877\", \"email\": \"admission@cadt.edu.kh\", \"office_location\": \"CADT Innovation Center: Bridge 2, National Road 6A, Sangkat Prek Leap, Khan Chroy Changva Phnom Penh.\"}'),(3,2,'Bachelor\'s Degree Admission Requirements','{\"proof_of_identity\": {\"options\": [\"Cambodia National Identity Card\", \"Passport\", \"Birth Certificate\"], \"description\": \"You must submit one of your official identification documents for verification:\"}, \"entrance_examination\": {\"options\": [\"Institute of Foreign Languages (IFL): Mandatory English or French entrance test\", \"Institute for International Studies and Public Policy (IISPP): General knowledge, logic, and English writing evaluation papers\", \"Department of Computer Science / Engineering: Fundamental mathematics and logic metrics screening\"], \"description\": \"Direct entry is allocated based on priority Grade 12 scores for general majors, but premium specialized departments require an additional examination:\"}, \"proof_of_high_school_graduation\": {\"options\": [\"A High School National Diploma (Grade 12 certificate)\", \"An official High School Transcript / Grade Report\"], \"description\": \"You must provide official proof that you have successfully completed high school:\"}}','2026-07-14 07:52:36','2026-07-14 07:52:36','Comprehensive admission criteria for entering undergraduate programs at the Royal University of Phnom Penh (RUPP).','{\"tel\": \"023 883 640\", \"email\": \"info@rupp.edu.kh\", \"office_location\": \"RUPP Campus I: Main Administration Building, Russian Federation Blvd, Phnom Penh\"}'),(4,3,'Bachelor\'s Degree Admission Requirements','{\"proof_of_identity\": {\"options\": [\"Cambodia National Identity Card\", \"Passport\", \"Birth Certificate\"], \"description\": \"You must submit one of your official identification documents for verification:\"}, \"entrance_examination\": {\"options\": [\"Mathematics Examination (Duration: 2 hours)\", \"Logic and Reasoning Assessment (Duration: 1 hour)\", \"Combined Physics and Chemistry Examination (Duration: 2 hours)\"], \"description\": \"All freshman engineering tracks require clearing the highly competitive STEM entrance assessment:\"}, \"proof_of_high_school_graduation\": {\"options\": [\"A High School National Diploma (Grade 12 certificate) or equivalent\", \"An official High School Transcript / Grade Report\"], \"description\": \"You must provide official proof that you have successfully completed high school:\"}}','2026-07-14 07:52:49','2026-07-14 07:52:49','Comprehensive admission criteria for entering undergraduate programs at the Institute of Technology of Cambodia (ITC / Sala Techno).','{\"tel\": \"855 23 880 370 / 982 404\", \"email\": \"info@itc.edu.kh\", \"office_location\": \"ITC Main Campus: PO Box 86, Russian Conf. Blvd. Phnom Penh, Cambodia\"}'),(5,4,'NUM Bachelor\'s Degree Admission Requirements','{\"proof_of_identity\": {\"options\": [\"Cambodia National Identity Card\", \"Passport\", \"Birth Certificate\"], \"description\": \"You must submit one of your official identification documents for verification:\"}, \"program_entry_tracks\": {\"options\": [\"National Programs: Direct grade priority selection matching high school diploma metrics\", \"International Bachelor\'s Programs (NUM International College / FDE): Compulsory internal English proficiency diagnostics evaluation and a brief placement interview round\"], \"description\": \"Admission guidelines differ depending on whether you are tracking into national or global academic programs:\"}, \"proof_of_high_school_graduation\": {\"options\": [\"A High School National Diploma (Grade 12 certificate)\", \"An official High School Transcript / Grade Report\"], \"description\": \"You must provide official proof that you have successfully completed high school:\"}}','2026-07-14 07:53:12','2026-07-14 07:53:12','Comprehensive admission criteria for entering undergraduate programs at the National University of Management (NUM).','{\"tel\": \"023 428 120\", \"email\": \"info@num.edu.kh\", \"office_location\": \"NUM Main Campus: Corner of Monivong Blvd and St. 96, Daun Penh, Phnom Penh\"}'),(6,5,'Bachelor\'s Degree Admission Requirements','{\"proof_of_identity\": {\"options\": [\"Cambodia National Identity Card\", \"Passport\", \"Birth Certificate\"], \"description\": \"You must submit one of your official identification documents for verification:\"}, \"proof_of_english_proficiency\": {\"options\": [\"IELTS overall band score of 5.5 or higher\", \"TOEFL iBT score of at least 60 or higher\", \"GEP Level 12 Certificate from Australian Center for Education\"], \"description\": \"As the primary medium of instruction is English, students must verify language proficiency to bypass the foundation program year:\"}, \"proof_of_high_school_graduation\": {\"options\": [\"A High School National Diploma (Grade 12 certificate)\", \"An official High School Transcript / Grade Report\"], \"description\": \"You must provide official proof that you have successfully completed high school:\"}}','2026-07-14 07:53:48','2026-07-14 07:53:48','Comprehensive admission criteria for entering undergraduate programs at Paragon International University (ParagonIU).','{\"tel\": \"+855-23-996-111, +855-17-996-111, or +855-15-996-111\", \"email\": \"admission@paragoniu.edu.kh\", \"office_location\": \"ParagonIU Reception Desk: No. 8 St. 315, Boeng Kak 1, Tuol Kork Phnom Penh, Cambodia\"}');
/*!40000 ALTER TABLE `Admissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Bookmark_Scholarship`
--

DROP TABLE IF EXISTS `Bookmark_Scholarship`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Bookmark_Scholarship` (
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `userId` int NOT NULL,
  `scholarshipId` int NOT NULL,
  PRIMARY KEY (`userId`,`scholarshipId`),
  KEY `scholarshipId` (`scholarshipId`),
  CONSTRAINT `Bookmark_Scholarship_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `Users` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Bookmark_Scholarship_ibfk_2` FOREIGN KEY (`scholarshipId`) REFERENCES `Scholarships` (`scholarshipId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Bookmark_Scholarship`
--

LOCK TABLES `Bookmark_Scholarship` WRITE;
/*!40000 ALTER TABLE `Bookmark_Scholarship` DISABLE KEYS */;
/*!40000 ALTER TABLE `Bookmark_Scholarship` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Bookmark_University`
--

DROP TABLE IF EXISTS `Bookmark_University`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Bookmark_University` (
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `userId` int NOT NULL,
  `universityId` int NOT NULL,
  PRIMARY KEY (`userId`,`universityId`),
  KEY `universityId` (`universityId`),
  CONSTRAINT `Bookmark_University_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `Users` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Bookmark_University_ibfk_2` FOREIGN KEY (`universityId`) REFERENCES `Universities` (`universityId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Bookmark_University`
--

LOCK TABLES `Bookmark_University` WRITE;
/*!40000 ALTER TABLE `Bookmark_University` DISABLE KEYS */;
/*!40000 ALTER TABLE `Bookmark_University` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Facilities`
--

DROP TABLE IF EXISTS `Facilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Facilities` (
  `facilityId` int NOT NULL AUTO_INCREMENT,
  `universityId` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `imageUrl` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`facilityId`),
  KEY `universityId` (`universityId`),
  CONSTRAINT `Facilities_ibfk_1` FOREIGN KEY (`universityId`) REFERENCES `Universities` (`universityId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Facilities`
--

LOCK TABLES `Facilities` WRITE;
/*!40000 ALTER TABLE `Facilities` DISABLE KEYS */;
/*!40000 ALTER TABLE `Facilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FundingTypes`
--

DROP TABLE IF EXISTS `FundingTypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FundingTypes` (
  `fundingId` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`fundingId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FundingTypes`
--

LOCK TABLES `FundingTypes` WRITE;
/*!40000 ALTER TABLE `FundingTypes` DISABLE KEYS */;
INSERT INTO `FundingTypes` VALUES (1,'Full Tuition Fee','2026-07-07 15:43:49','2026-07-07 15:43:49'),(2,'Fully Funded','2026-07-07 15:43:49','2026-07-07 15:43:49'),(3,'Partially Funded','2026-07-07 15:43:49','2026-07-07 15:43:49');
/*!40000 ALTER TABLE `FundingTypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Majors`
--

DROP TABLE IF EXISTS `Majors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Majors` (
  `majorId` int NOT NULL AUTO_INCREMENT,
  `academicUnitId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `degreeLevel` enum('Associate','Bachelor','Master','PhD') NOT NULL,
  `tuitionFee` decimal(10,2) DEFAULT NULL,
  `description` text,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`majorId`),
  KEY `academicUnitId` (`academicUnitId`),
  CONSTRAINT `Majors_ibfk_1` FOREIGN KEY (`academicUnitId`) REFERENCES `AcademicUnits` (`academicUnitId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Majors`
--

LOCK TABLES `Majors` WRITE;
/*!40000 ALTER TABLE `Majors` DISABLE KEYS */;
INSERT INTO `Majors` VALUES (1,13,'Software Engineering','Bachelor',2500.00,'Aim to provide a skillfull Bachelor of Computer Science specialized in Software Engineering. Students will also develop the skills necessary to solve complex technical problems and contribute to the community and society.','2026-07-13 17:10:55','2026-07-13 17:10:55'),(2,13,'Data Science','Bachelor',2500.00,'Aim to provide a skillfull Bachelor degree of Computer Science specialized in Data Science. Students will work in various settings, including research organizations, businesses, or government agencies.','2026-07-13 17:11:27','2026-07-13 17:11:27'),(3,14,'Telecommunications and Networking Engineering','Bachelor',2500.00,'Offers a cutting-edge program in Telecommunications and Network Engineering. Students will learn to design and optimize networks, equipping them for the ever-evolving world of technology.','2026-07-13 17:11:41','2026-07-13 17:11:41'),(4,14,'Cyber Security','Bachelor',2500.00,'The program equips studetns with the skills and knowledge to protect data and information from cyber threats. You will learn about network security, cryptography, ethical hacking, and more.','2026-07-13 17:12:03','2026-07-13 17:12:03'),(5,15,'E-Commerce','Bachelor',2500.00,'The program specifically designed to prepare students for the contemporary workforce and a global career especially for the emerging market.','2026-07-13 17:12:17','2026-07-13 17:12:17'),(6,26,'Business Administration','Bachelor',6000.00,'Prepares students for global corporate leadership, management, and entrepreneurial innovation tracks.','2026-07-13 18:09:14','2026-07-13 18:09:14'),(7,26,'Communication','Bachelor',9000.00,'This program is designed to provide students with a comprehensive understanding of effective communication strategies and business principles, preparing them for a wide range of career opportunities in various industries.','2026-07-13 18:09:32','2026-07-13 18:09:32'),(8,26,'e-Society (Digital Marketing)','Bachelor',9000.00,'This program equips students with a comprehensive understanding of data management, digital technologies, social media, and their implications for businesses and society.','2026-07-13 18:09:41','2026-07-13 18:09:41'),(9,27,'Artificial Intelligence (AI)','Bachelor',6000.00,'Aims to equip students with a strong foundation and advanced skills in AI. Core courses like Introduction to AI, Machine Learning, and Generative AI prepare graduates for careers in AI research and industry.','2026-07-13 18:09:51','2026-07-13 18:09:51'),(10,27,'Computer Science','Bachelor',9000.00,'Delivers comprehensive education in programming languages, web development, and software engineering in partnership with U.S. institutional standards.','2026-07-13 18:10:00','2026-07-13 18:10:00'),(11,27,'Cybersecurity','Bachelor',6000.00,'Focuses on security architecture, defensive network monitoring, ethical hacking, and information governance protocols.','2026-07-13 18:10:07','2026-07-13 18:10:07'),(12,27,'Data Analytics','Bachelor',6000.00,'Equips students with methods for data harvesting, pattern identification, and predictive analytics models.','2026-07-13 18:10:17','2026-07-13 18:10:17'),(13,27,'Digital Infrastructure','Bachelor',6000.00,'The Digital Infrastructure degree program focuses on mastering cloud infrastructure, virtualization, services, and secure deployment models.','2026-07-13 18:10:24','2026-07-13 18:10:24'),(14,27,'Information and Communications Technology','Bachelor',6000.00,'Designed to develop graduates with the ability to manage, support, and lead complex computer-based enterprise information systems.','2026-07-13 18:10:32','2026-07-13 18:10:32'),(15,27,'Interactive App Design and Development','Bachelor',6000.00,'Hones technical execution skills in crafting, maintaining, and optimizing cross-platform web and mobile software applications.','2026-07-13 18:10:39','2026-07-13 18:10:39'),(16,27,'Software Development','Bachelor',6000.00,'Emphasizes the complete software engineering lifecycle, agile design, full-stack programming patterns, and systematic quality assurance testing.','2026-07-13 18:10:47','2026-07-13 18:10:47'),(17,28,'Law','Bachelor',6000.00,'Develops a critical core understanding of cross-border legal systems, corporate frameworks, and standard judicial analysis procedures.','2026-07-13 18:10:55','2026-07-13 18:10:55'),(18,29,'International Relations and Diplomacy','Bachelor',6000.00,'Analyzes macroeconomic forces, geopolitical dynamics, conflict resolution strategies, and contemporary foreign policy frameworks.','2026-07-13 18:12:52','2026-07-13 18:12:52'),(19,1,'Chinese','Bachelor',600.00,'','2026-07-14 08:57:57','2026-07-14 08:57:57'),(20,1,'English','Bachelor',600.00,'','2026-07-14 08:58:15','2026-07-14 08:58:15'),(21,1,'French','Bachelor',600.00,'','2026-07-14 08:58:23','2026-07-14 08:58:23'),(22,1,'Japanese','Bachelor',600.00,'','2026-07-14 08:58:36','2026-07-14 08:58:36'),(23,1,'Korean','Bachelor',600.00,'','2026-07-14 08:58:46','2026-07-14 08:58:46'),(24,1,'Thai','Bachelor',600.00,'','2026-07-14 08:58:55','2026-07-14 08:58:55'),(25,2,'Computer Science','Bachelor',600.00,'','2026-07-14 08:59:07','2026-07-14 08:59:07'),(26,2,'Mathematics','Bachelor',500.00,'','2026-07-14 08:59:15','2026-07-14 08:59:15'),(27,2,'Physics','Bachelor',500.00,'','2026-07-14 08:59:25','2026-07-14 08:59:25'),(28,2,'Chemistry','Bachelor',500.00,'','2026-07-14 08:59:33','2026-07-14 08:59:33'),(29,2,'Biology','Bachelor',500.00,'','2026-07-14 08:59:41','2026-07-14 08:59:41'),(30,2,'Environmental Science','Bachelor',500.00,'','2026-07-14 08:59:48','2026-07-14 08:59:48'),(31,3,'Environmental Engineering','Bachelor',800.00,'','2026-07-14 09:00:08','2026-07-14 09:00:08'),(32,3,'Bio-Engineering','Bachelor',800.00,'','2026-07-14 09:00:19','2026-07-14 09:00:19'),(33,3,'Information Technology Engineering','Bachelor',800.00,'','2026-07-14 09:00:30','2026-07-14 09:00:30'),(34,3,'Telecommunication and Electronic Engineering','Bachelor',800.00,'','2026-07-14 09:00:40','2026-07-14 09:00:40'),(35,3,'Automation and Supply Chain Engineering','Bachelor',800.00,'','2026-07-14 09:00:49','2026-07-14 09:00:49'),(36,4,'International Relations (DIR)','Bachelor',800.00,'','2026-07-14 09:00:59','2026-07-14 09:00:59'),(37,4,'International Economic (D.I.Eco)','Bachelor',800.00,'','2026-07-14 09:01:07','2026-07-14 09:01:07'),(38,4,'Political Science and Public Policy (DPSPP)','Bachelor',800.00,'','2026-07-14 09:01:15','2026-07-14 09:01:15'),(39,4,'Vietnamese Studies (D.V.N.S)','Bachelor',800.00,'','2026-07-14 09:01:22','2026-07-14 09:01:22'),(40,5,'Community Development','Bachelor',600.00,'','2026-07-14 09:01:31','2026-07-14 09:01:31'),(41,5,'Economic Development','Bachelor',600.00,'','2026-07-14 09:01:39','2026-07-14 09:01:39'),(42,5,'Natural Resource Management and Development','Bachelor',600.00,'','2026-07-14 09:01:46','2026-07-14 09:01:46'),(43,5,'Sustainable Urban Planning and Development','Bachelor',600.00,'','2026-07-14 09:01:53','2026-07-14 09:01:53'),(44,6,'Lifelong Learning','Bachelor',500.00,'','2026-07-14 09:02:01','2026-07-14 09:02:01'),(45,6,'Education Studies','Bachelor',500.00,'','2026-07-14 09:02:12','2026-07-14 09:02:12'),(46,6,'Higher Education Development and Management','Bachelor',500.00,'','2026-07-14 09:02:20','2026-07-14 09:02:20'),(47,7,'Tourism','Bachelor',600.00,'','2026-07-14 09:02:28','2026-07-14 09:02:28'),(48,7,'Social Work','Bachelor',600.00,'','2026-07-14 09:02:35','2026-07-14 09:02:35'),(49,7,'Sociology','Bachelor',450.00,'','2026-07-14 09:02:42','2026-07-14 09:02:42'),(50,7,'Psychology','Bachelor',500.00,'','2026-07-14 09:02:52','2026-07-14 09:02:52'),(51,7,'Philosophy','Bachelor',450.00,'','2026-07-14 09:03:00','2026-07-14 09:03:00'),(52,7,'Media and Communication','Bachelor',900.00,'','2026-07-14 09:03:07','2026-07-14 09:03:07'),(53,7,'Linguistics','Bachelor',450.00,'','2026-07-14 09:03:15','2026-07-14 09:03:15'),(54,7,'International Business Management','Bachelor',450.00,'','2026-07-14 09:03:23','2026-07-14 09:03:23'),(55,7,'Khmer Literature','Bachelor',450.00,'','2026-07-14 09:03:32','2026-07-14 09:03:32'),(56,7,'History','Bachelor',450.00,'','2026-07-14 09:03:42','2026-07-14 09:03:42'),(57,7,'Geography and Land Management','Bachelor',450.00,'','2026-07-14 09:03:50','2026-07-14 09:03:50'),(58,8,'Electrical and Energy Engineering','Bachelor',700.00,'','2026-07-14 09:28:32','2026-07-14 09:28:32'),(59,8,'Industrial and Mechanical Engineering','Bachelor',700.00,'','2026-07-14 09:28:44','2026-07-14 09:28:44'),(60,8,'Information and Communications Technology','Bachelor',700.00,'','2026-07-14 09:28:51','2026-07-14 09:28:51'),(61,8,'Telecommunications and Networking Engineering','Bachelor',700.00,'','2026-07-14 09:28:59','2026-07-14 09:28:59'),(62,8,'Applied Mathematics and Statistics','Bachelor',700.00,'','2026-07-14 09:29:08','2026-07-14 09:29:08'),(63,8,'Department of E-Learning','Bachelor',700.00,'','2026-07-14 09:29:32','2026-07-14 09:29:32'),(64,9,'Civil Engineering','Bachelor',700.00,'','2026-07-14 09:29:48','2026-07-14 09:29:48'),(65,9,'Architectural Engineering','Bachelor',700.00,'','2026-07-14 09:29:56','2026-07-14 09:29:56'),(66,9,'Infrastructure and Transportation','Bachelor',700.00,'','2026-07-14 09:30:04','2026-07-14 09:30:04'),(67,10,'Chemical Engineering','Bachelor',700.00,'','2026-07-14 09:30:13','2026-07-14 09:30:13'),(68,10,'Food Science and Technology','Bachelor',700.00,'','2026-07-14 09:30:24','2026-07-14 09:30:24'),(69,11,'Water Resources and Rural Infrastructure','Bachelor',700.00,'','2026-07-14 09:30:32','2026-07-14 09:30:32'),(70,11,'Water Enviromental Engineering','Bachelor',700.00,'','2026-07-14 09:31:16','2026-07-14 09:31:16'),(71,12,'Geo-resources Petroleum','Bachelor',700.00,'','2026-07-14 09:31:26','2026-07-14 09:31:26'),(72,12,'Geotechnical Engineering','Bachelor',700.00,'','2026-07-14 09:31:52','2026-07-14 09:31:52'),(73,16,'Management','Bachelor',NULL,'','2026-07-14 09:54:37','2026-07-14 09:54:37'),(74,16,'Marketing','Bachelor',NULL,'','2026-07-14 09:55:13','2026-07-14 09:55:13'),(75,16,'Entrepreneurship','Bachelor',NULL,'','2026-07-14 09:55:23','2026-07-14 09:55:23'),(76,17,'Accounting','Bachelor',NULL,'','2026-07-14 09:55:30','2026-07-14 09:55:30'),(77,17,'Accounting and Auditing','Bachelor',NULL,'','2026-07-14 09:55:38','2026-07-14 09:55:38'),(78,17,'Accounting and Taxation','Bachelor',NULL,'','2026-07-14 09:56:11','2026-07-14 09:56:11'),(79,17,'Finance and Insurance','Bachelor',NULL,'','2026-07-14 09:56:28','2026-07-14 09:56:28'),(80,17,'Finance and Security Market','Bachelor',NULL,'','2026-07-14 09:56:37','2026-07-14 09:56:37'),(81,17,'Finance and Banking','Bachelor',NULL,'','2026-07-14 09:56:54','2026-07-14 09:56:54'),(82,18,'Information Technology','Bachelor',NULL,'','2026-07-14 09:57:01','2026-07-14 09:57:01'),(83,18,'Robotic and Artificial Intelligence (AI)','Bachelor',NULL,'','2026-07-14 09:57:08','2026-07-14 09:57:08'),(84,19,'Business Economics','Bachelor',NULL,'','2026-07-14 09:57:16','2026-07-14 09:57:16'),(85,19,'Economics for Development','Bachelor',NULL,'','2026-07-14 09:57:25','2026-07-14 09:57:25'),(86,20,'English Literature','Bachelor',NULL,'','2026-07-14 09:57:31','2026-07-14 09:57:31'),(87,21,'Tourism','Bachelor',NULL,'','2026-07-14 09:57:42','2026-07-14 09:57:42'),(88,21,'Hospitality','Bachelor',NULL,'','2026-07-14 09:57:50','2026-07-14 09:57:50'),(89,22,'Bachelor of Law','Bachelor',NULL,'','2026-07-14 10:00:11','2026-07-14 10:00:11'),(90,22,'Public Administration Management','Bachelor',NULL,'','2026-07-14 10:00:24','2026-07-14 10:00:24'),(91,23,'Architecture (ARC)','Bachelor',4500.00,'','2026-07-14 10:11:58','2026-07-14 10:11:58'),(92,23,'Civil Engineering (CE)','Bachelor',4500.00,'','2026-07-14 10:12:09','2026-07-14 10:12:09'),(93,23,'Industrial Engineering (IE)','Bachelor',4500.00,'','2026-07-14 10:12:16','2026-07-14 10:12:16'),(94,24,'Computer Science (CS)','Bachelor',4000.00,'','2026-07-14 10:12:24','2026-07-14 10:12:24'),(95,24,'Digital Arts and Design (DAD)','Bachelor',4000.00,'','2026-07-14 10:13:11','2026-07-14 10:13:11'),(96,24,'Management of Information Systems (MIS)','Bachelor',4000.00,'','2026-07-14 10:13:24','2026-07-14 10:13:24'),(97,25,'Banking and Finance (BAF)','Bachelor',3500.00,'','2026-07-14 10:13:31','2026-07-14 10:13:31'),(98,25,'Economics (ECON)','Bachelor',3500.00,'','2026-07-14 10:13:41','2026-07-14 10:13:41'),(99,25,'Business Administration (BUS)','Bachelor',3500.00,'','2026-07-14 10:13:47','2026-07-14 10:13:47'),(100,25,'International Trade and Logistics (ITL)','Bachelor',3500.00,'','2026-07-14 10:13:57','2026-07-14 10:13:57'),(101,25,'International Relations (IR)','Bachelor',3500.00,'','2026-07-14 10:14:04','2026-07-14 10:14:04'),(102,25,'Business Administration (BUS)','Bachelor',3500.00,'','2026-07-14 10:14:13','2026-07-14 10:14:13');
/*!40000 ALTER TABLE `Majors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Profiles`
--

DROP TABLE IF EXISTS `Profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Profiles` (
  `profileId` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `dateOfBirth` date DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `nationality` varchar(255) DEFAULT NULL,
  `bio` text,
  `phoneNumber` varchar(255) DEFAULT NULL,
  `address` text,
  `avatarUrl` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`profileId`),
  KEY `userId` (`userId`),
  CONSTRAINT `Profiles_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `Users` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Profiles`
--

LOCK TABLES `Profiles` WRITE;
/*!40000 ALTER TABLE `Profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `Profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Providers`
--

DROP TABLE IF EXISTS `Providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Providers` (
  `providerId` int NOT NULL AUTO_INCREMENT,
  `providerName` varchar(255) NOT NULL,
  `providerType` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `providerLogo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`providerId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Providers`
--

LOCK TABLES `Providers` WRITE;
/*!40000 ALTER TABLE `Providers` DISABLE KEYS */;
INSERT INTO `Providers` VALUES (1,'Ministry of Post And Telecommunications (MPTC)','Government','2026-07-07 15:55:42','2026-07-07 15:55:42','https://cadt.edu.kh/wp-content/uploads/2024/10/SMALL-Techo_Talent_Scholarship_Banner_2022.png');
/*!40000 ALTER TABLE `Providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Roles`
--

DROP TABLE IF EXISTS `Roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Roles` (
  `roleId` int NOT NULL AUTO_INCREMENT,
  `roleName` varchar(20) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`roleId`),
  UNIQUE KEY `roleName` (`roleName`),
  UNIQUE KEY `roleName_2` (`roleName`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Roles`
--

LOCK TABLES `Roles` WRITE;
/*!40000 ALTER TABLE `Roles` DISABLE KEYS */;
INSERT INTO `Roles` VALUES (1,'ADMIN','System administrator',1,'2026-07-07 13:57:32','2026-07-07 13:57:32'),(2,'USER','Normal registered user',1,'2026-07-07 13:57:32','2026-07-07 13:57:32');
/*!40000 ALTER TABLE `Roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Scholarship_Major`
--

DROP TABLE IF EXISTS `Scholarship_Major`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Scholarship_Major` (
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `scholarshipId` int NOT NULL,
  `majorId` int NOT NULL,
  PRIMARY KEY (`scholarshipId`,`majorId`),
  KEY `majorId` (`majorId`),
  CONSTRAINT `Scholarship_Major_ibfk_1` FOREIGN KEY (`scholarshipId`) REFERENCES `Scholarships` (`scholarshipId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Scholarship_Major_ibfk_2` FOREIGN KEY (`majorId`) REFERENCES `Majors` (`majorId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Scholarship_Major`
--

LOCK TABLES `Scholarship_Major` WRITE;
/*!40000 ALTER TABLE `Scholarship_Major` DISABLE KEYS */;
/*!40000 ALTER TABLE `Scholarship_Major` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Scholarships`
--

DROP TABLE IF EXISTS `Scholarships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Scholarships` (
  `scholarshipId` int NOT NULL AUTO_INCREMENT,
  `fundingId` int NOT NULL,
  `providerId` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `studyIn` varchar(255) DEFAULT NULL,
  `description` text,
  `degreeLevel` varchar(255) DEFAULT NULL,
  `minAmount` decimal(10,2) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `availableSlots` int DEFAULT NULL,
  `benefits` json DEFAULT NULL,
  `majorOffered` json DEFAULT NULL,
  `applicationDeadline` datetime DEFAULT NULL,
  `applicationProcess` json DEFAULT NULL,
  `applicationLink` varchar(255) DEFAULT NULL,
  `documentRequirements` json DEFAULT NULL,
  `eligibilityCriteria` json DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `maxAmount` decimal(10,2) DEFAULT NULL,
  `coverImage` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`scholarshipId`),
  KEY `fundingId` (`fundingId`),
  KEY `providerId` (`providerId`),
  CONSTRAINT `Scholarships_ibfk_3` FOREIGN KEY (`fundingId`) REFERENCES `FundingTypes` (`fundingId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Scholarships_ibfk_4` FOREIGN KEY (`providerId`) REFERENCES `Providers` (`providerId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Scholarships`
--

LOCK TABLES `Scholarships` WRITE;
/*!40000 ALTER TABLE `Scholarships` DISABLE KEYS */;
INSERT INTO `Scholarships` VALUES (1,1,1,'Techo Digital Talent Scholarships','Cambodia','Techo Digital Talent Scholarship Program has been established with the goal of strengthening Cambodia’s pool of skilled digital human resources. This will form the foundation of the nation’s digital workforce, supporting the transformation of Cambodia’s economy into a digital economy.','Bachelor',3100.00,'USD',600,'[\"One laptop\", \"100% tuition coverage until completion of the bachelor’s degree\", \"Opportunities for high-paying jobs in ministries, institutions, or technology companies both locally and abroad\", \"Support and facilitation from MPTC to ensure successful completion of the 4-year program\"]','[\"Software Engineering\", \"Data Science\", \"E-Commerce\", \"Telecommunications and Networking Engineering\", \"Cybersecurity\", \"AI Engineering and Cybersecurity\", \"Telecommunications and Electronic Engineering\", \"Information Technology Engineering\", \"Data Economy\", \"Financial Technology\", \"Global Entrepreneurship and Innovation\", \"Computer Science\", \"Management of Information Systems\", \"Digital Arts and Design\", \"Information and Communication Technology\", \"Artificial Intelligence\", \"Digital Infrastructure\", \"Data Analytics\", \"Interactive App Design and Development\", \"Software Development\"]','2026-09-30 00:00:00','[\"Online Registration: Students can register via the link from the announcement date until September 30, 2026.\", \"Ticket Collection: After completing the online registration, candidates must pick up their physical test admission ticket at the Cambodia Academy of Digital Technology (CADT) building.\", \"Examination Details: The entrance test is conducted on-site at the CADT building during regular working hours from Monday to Friday.\"]','http://www.cadt.edu.kh/scholarship','[\"National ID or passport\", \"Official High School National Exam Result (Bac II)\"]','[\"Must be students who passed the 2025 National High School Examination with grades A, B, or C\", \"Must pass a computer-based competitive exam in Mathematics, Logical Reasoning, and English\"]','Open','2026-07-07 17:30:34','2026-07-07 17:30:34',24700.00,'https://ctc.edu.kh/_astro/thumbnail.BFOxsBxN.jpeg');
/*!40000 ALTER TABLE `Scholarships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Universities`
--

DROP TABLE IF EXISTS `Universities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Universities` (
  `universityId` int NOT NULL AUTO_INCREMENT,
  `campusName` varchar(255) NOT NULL,
  `shortName` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `websiteUrl` varchar(255) DEFAULT NULL,
  `logoUrl` varchar(255) DEFAULT NULL,
  `coverImageUrl` varchar(255) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phoneNumber` varchar(255) DEFAULT NULL,
  `address` text,
  `description` json DEFAULT NULL,
  `vision` json DEFAULT NULL,
  `mission` json DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `minAmount` decimal(10,2) DEFAULT NULL,
  `maxAmount` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`universityId`),
  UNIQUE KEY `campusName` (`campusName`),
  UNIQUE KEY `campusName_2` (`campusName`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Universities`
--

LOCK TABLES `Universities` WRITE;
/*!40000 ALTER TABLE `Universities` DISABLE KEYS */;
INSERT INTO `Universities` VALUES (1,'Cambodia Academy of Digital Technology','CADT','Public','https://www.cadt.edu.kh','https://www.cadt.edu.kh/wp-content/uploads/2023/02/cadt_square_logo_boundary.jpg','https://cadt.edu.kh/wp-content/uploads/2024/06/Our-10th-Anniversary-Celebration-scaled.webp','','Phnom Penh','info@cadt.edu.kh','+855-23-999-000','Bridge 2, National Road 6A, Sangkat Prek Leap, Khan Chroy Changva, Phnom Penh','\"CADT is a leading public research and education institution in Cambodia, dedicated to accelerating a vibrant, inclusive, and sustainable digital society.\"','[\"To be the flagship public education and research institution, developing excellent digital talent and innovators, driving Cambodia toward a digital society.\"]','[\"To provide education, training, R&D and promote innovation on digital technology to students, civil servants, and innovators to contribute to the development of digital government, economy and society.\"]','2026-07-05 14:26:34','2026-07-05 14:26:34',NULL,NULL),(2,'Royal University of Phnom Penh','RUPP','Public','http://www.rupp.edu.kh','https://upload.wikimedia.org/wikipedia/km/e/ee/Rupp_logo.png','https://www.rupp.edu.kh/assets/researchers_rupp.png','','Phnom Penh','info@rupp.edu.kh','(+855) 23 724 370','Russian Federation Blvd, Phnom Penh, Cambodia','\"The Royal University of Phnom Penh is Cambodia\'s oldest and largest public university, offering degrees in science, technology, humanities, and social sciences.\"','[\"Our vision is to be Cambodia’s flagship university with regional standing in teaching and learning, research and innovation, and social engagement by 2030.\"]','[\"Equipping students with the essential knowledge, skills, competence, values, and attitudes required by the information- and knowledge-based society\", \"Providing high-quality research and innovations\", \"Being actively engaged with society\"]','2026-07-05 14:26:49','2026-07-05 14:26:49',NULL,NULL),(3,'Institute of Technology of Cambodia','ITC','Public','https://www.itc.edu.kh','https://itc.edu.kh/wp-content/uploads/2021/02/cropped-Logo-ITC-1024x1004.png','https://www.itc.edu.kh/assets/images/itc-campus.jpg','','Phnom Penh','info@itc.edu.kh','+855 23 880 370 / 982 404','PO Box 86, Russian Federation Blvd., Sangkat Teuklaak 1, Khan Toul Kork, 120404, Phnom Penh, Cambodia','\"The Institute of Technology of Cambodia is recognized as the top leading the public higher education institution in engineering and technology in Cambodia. The Institute was founded in 1964 as Institut Technique Supérieur de l’Amitié Khméro–Soviétique (ITSAKS), in cooperation with the Soviet Union from 1964 to 1975 and from 1980 to 1991. In 1993, the Institute was renamed as Institut de Technologie du Cambodge, it was operated by French until 2004. From 2004 to present, the Institute has been operated by Cambodian, under the Ministry of Education Youth and Sport.\"','[\"ITC aspires to be the foremost university in Cambodia, excelling in education and research in Science, Technology and Engineering. Our vision extends to become one of the premier institutions in the region, excellence in Science, Technology and Engineering.\"]','[\"Cultivate talented and skilled graduates in science, technology and engineering by 2030\", \"Drive applied research aims at fostering start-up and technology transfer by 2030\"]','2026-07-05 14:27:02','2026-07-05 14:27:02',NULL,NULL),(4,'National University of Management','NUM','Public','https://numuniversity.com/','https://numuniversity.com/wp-content/uploads/2025/08/NUM-Logo-oiriginal-1.png','https://academics-bucket-sj19asxm-prod.s3.ap-southeast-1.amazonaws.com/8c724f2a-32b5-4b3d-80b3-14c4b365388d/d64e6f44-6806-4b80-987f-735e6bc9ad63.jpg','','Phnom Penh','sengbunthoeun@num.edu.kh','+855 95 504 179','St.96 Christopher Howes, Khan Daun Penh, Phnom Penh, Cambodia','\"The National University of Management (NUM) is Cambodia’s leading university for business, management, economics, law, and digital economy studies. Located in Phnom Penh, NUM offers bachelor’s, master’s, and doctoral programs with strong international partnerships and a focus on research, innovation, and entrepreneurship\"','[\"NUM is dedicated to becoming a leading hub for academic research and innovation, shaping new knowledge both within Cambodia and on the global stage. Faculty members and teachers are actively engaged in conducting and publishing new research, and students, especially at the graduate level, are crucial to this process.\"]','[\"Cultivate Innovative Leaders, Managers, and Entrepreneurs for Society\", \"The mission outlines the practical steps to achieve the vision. NUM is committed to training proactive, creative, and strategic professionals who are equipped with the skills to drive progress and make a meaningful impact on the economy and society.\"]','2026-07-05 14:27:15','2026-07-05 14:27:15',NULL,NULL),(5,'Zaman University (Paragon International University)','ParagonIU','Private','https://www.paragoniu.edu.kh','https://cdn.brandfetch.io/domain/paragoniu.edu.kh/fallback/lettermark/theme/dark/h/400/w/400/icon?c=1bfwsmEH20zzEfSNTed','https://sustainability-ai.org/paragon_university.jpg','','Phnom Penh','info@paragoniu.edu.kh','+855-23-996-111','No. 8, St. 315,Boeng Kak 1, Tuol Kork, Phnom Penh, Cambodia, 12151','\"Paragon International University is a leading private university in Cambodia offering international-standard education completely in English.\"','[\"Paragon International University strives to become a leading, private, higher education institution in Cambodia in terms of the quality of teaching, research, student enrichment, community service, as well as regional and global engagement.\"]','[\"Become a leading institution in providing students with inquiry-based study and scholarship, yielding: disciplinary expertise, soft skills, cross-cultural and technological competence, an innovative mindset, employability, and a sense of social responsibility\", \"Become a leading institution in engineering, technology, and the administrative and social sciences\", \"Become a leading institution modeling good governance, in which administrative, financial, and student services are digitized, transparent, inclusive, and accountable to all stakeholders\", \"Become a leading institution in producing research, consultancy, and community services\", \"Become a leading institution that embraces life-long education, regional and global relationships, and the highest ethical standards.\"]','2026-07-05 14:27:26','2026-07-05 14:27:26',NULL,NULL),(6,'American University of Phnom Penh','AUPP','Private','https://www.aupp.edu.kh','https://www.aupp.edu.kh/wp-content/uploads/AUPP-Block-Logo.png','https://www.aupp.edu.kh/wp-content/uploads/AUPP-Building.jpg','','Phnom Penh','info@aupp.edu.kh','+855-23-990-023','https://maps.app.goo.gl/BKvPNJT4QLTKxsYL6','\"The American University of Phnom Penh (AUPP) is a premier, private higher education institution in Cambodia. Established in 2013, it offers an American-style liberal arts curriculum with dual-degree programs in partnership with U.S. institutions like the University of Arizona.\"','[\"The American University of Phnom Penh (AUPP) will be a leading center of academic excellence in Cambodia and in Asia.\", \"Recognized as thought leaders, we will be at the forefront of innovation and the partner of choice for industry.\"]','[\"AUPP is a private English language higher-education institution in Cambodia, offering high-quality American-style education that is grounded in the latest teaching & learning theories and the culture of Cambodia and Asia.\", \"The university fosters socially responsible behavior, life-long learning, and academic and professional excellence, producing critical thinkers, innovators, and ethical leaders who will make significant contributions.\"]','2026-07-05 14:27:41','2026-07-05 14:27:41',NULL,NULL);
/*!40000 ALTER TABLE `Universities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `University_Scholarship`
--

DROP TABLE IF EXISTS `University_Scholarship`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `University_Scholarship` (
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `universityId` int NOT NULL,
  `scholarshipId` int NOT NULL,
  PRIMARY KEY (`universityId`,`scholarshipId`),
  KEY `scholarshipId` (`scholarshipId`),
  CONSTRAINT `University_Scholarship_ibfk_1` FOREIGN KEY (`universityId`) REFERENCES `Universities` (`universityId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `University_Scholarship_ibfk_2` FOREIGN KEY (`scholarshipId`) REFERENCES `Scholarships` (`scholarshipId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `University_Scholarship`
--

LOCK TABLES `University_Scholarship` WRITE;
/*!40000 ALTER TABLE `University_Scholarship` DISABLE KEYS */;
/*!40000 ALTER TABLE `University_Scholarship` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Users` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `roleId` int NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username_2` (`username`),
  UNIQUE KEY `email_2` (`email`),
  KEY `roleId` (`roleId`),
  CONSTRAINT `Users_ibfk_1` FOREIGN KEY (`roleId`) REFERENCES `Roles` (`roleId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` VALUES (2,1,'David Yeat','david.yeat168@gmail.com','$2b$10$mVWcAM2XlsyinYrl33VnjuteA/UpATpJysxM0/sh/G18jTmM6gcp2','2026-07-07 13:58:16','2026-07-07 13:58:16'),(3,2,'Sereiwat','sosereiwat@gmail.com','$2b$10$Gz8JM1PzogCoKhjH5exk0eA/ml3gKvwQ34jvu7R2ynNab/yWgOiGa','2026-07-07 15:12:56','2026-07-07 15:12:56');
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-16 14:55:59
